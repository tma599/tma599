const express = require('express');
const router = express.Router();
const fsp = require('fs/promises');
const path = require('path');
const cron = require('node-cron');
const { CronExpressionParser } = require('cron-parser');
const { getBackupDir, executeBackup } = require('../utils/backupManager');
const { executeRestore } = require('../utils/backupRestorer');
const { backupSchedules, addSchedule, removeSchedule } = require('../models/backupSchedules');
const { reactionRoles, saveReactionRoles } = require('../models/reactionRoles');
const { ngWords, saveNgWords, normalizeJapanese } = require('../models/ngwords');
const { PermissionsBitField, ChannelType } = require('discord.js');

function ensureApiAuth(req, res, next) {
    if (req.isAuthenticated()) {
        return next();
    }
    res.status(401).json({ error: 'Unauthorized. Please log in again.' });
}

router.use(ensureApiAuth);

// Backups
router.get('/backups', async (req, res) => {
  const backupsPath = path.join(__dirname, '../backups');
  const targetGuildId = req.query.guildId;
  const backupType = req.query.type;

  try {
    const userFolders = await fsp.readdir(backupsPath, { withFileTypes: true });
    const allBackups = [];

    for (const userFolder of userFolders) {
      if (userFolder.isDirectory()) {
        const userId = userFolder.name;
        const userBackupDir = getBackupDir(userId);
        try {
          const files = await fsp.readdir(userBackupDir);
          let backupFiles = files.filter(file => file.endsWith('.json'));

          if (backupType === 'auto') {
            backupFiles = backupFiles.filter(file => file.startsWith('auto_'));
          } else if (backupType === 'manual') {
            backupFiles = backupFiles.filter(file => !file.startsWith('auto_'));
          }
          
          for (const file of backupFiles) {
             const filePath = path.join(userBackupDir, file);
             const data = await fsp.readFile(filePath, 'utf-8');
             const json = JSON.parse(data);

             if (targetGuildId && json.serverId !== targetGuildId) {
                 continue;
             }

             allBackups.push({
                 userId: userId,
                 fileName: file,
                 serverName: json.serverName || 'N/A',
                 createdAt: json.createdAt || 'N/A',
                 locked: json.locked || false,
                 guildId: json.serverId || 'N/A',
             });
          }
        } catch (err) {
          console.error(`[Web] Could not read backups for user ${userId}:`, err);
        }
      }
    }
    res.json(allBackups);
  } catch (error) {
    console.error('[Web] Error fetching backups:', error);
    if (error.code === 'ENOENT') {
        return res.json([]);
    }
    res.status(500).json({ error: 'Failed to retrieve backups.' });
  }
});

router.post('/backups/action', async (req, res) => {
    const { action, userId, fileName } = req.body;

    if (!action || !userId || !fileName) {
        return res.status(400).json({ error: 'Missing required parameters.' });
    }

    const backupDir = getBackupDir(userId);
    const backupFilePath = path.join(backupDir, fileName);

    try {
        await fsp.access(backupFilePath);
        const fileData = await fsp.readFile(backupFilePath, 'utf-8');
        const backupJson = JSON.parse(fileData);

        switch (action) {
            case 'lock':
                backupJson.locked = true;
                await fsp.writeFile(backupFilePath, JSON.stringify(backupJson, null, 2));
                console.log(`[Web] User ${req.user.username} locked backup ${fileName}`);
                res.json({ success: true, message: `File ${fileName} locked.` });
                break;
            case 'unlock':
                backupJson.locked = false;
                await fsp.writeFile(backupFilePath, JSON.stringify(backupJson, null, 2));
                console.log(`[Web] User ${req.user.username} unlocked backup ${fileName}`);
                res.json({ success: true, message: `File ${fileName} unlocked.` });
                break;
            case 'delete':
                if (backupJson.locked) {
                    return res.status(403).json({ error: 'Cannot delete a locked file.' });
                }
                await fsp.unlink(backupFilePath);
                console.log(`[Web] User ${req.user.username} deleted backup ${fileName}`);
                res.json({ success: true, message: `File ${fileName} deleted.` });
                break;
            default:
                res.status(400).json({ error: 'Invalid action.' });
        }
    } catch (error) {
        if (error.code === 'ENOENT') {
            return res.status(404).json({ error: `File ${fileName} not found.` });
        }
        console.error(`[Web] Error performing action ${action} on ${fileName}:`, error);
        res.status(500).json({ error: `Failed to perform action on ${fileName}.` });
  }
});

// Guilds
router.get('/guilds', (req, res) => {
    try {
        const guilds = req.client.guilds.cache.map(guild => ({
            id: guild.id,
            name: guild.name,
            iconURL: guild.iconURL(),
            memberCount: guild.memberCount,
        }));
        res.json(guilds);
    } catch (error) {
        console.error('[Web] Error fetching guilds:', error);
        res.status(500).json({ error: 'Failed to retrieve guilds.' });
    }
});

router.get('/guilds/:guildId', (req, res) => {
    try {
        const guildId = req.params.guildId;
        const guild = req.client.guilds.cache.get(guildId);

        if (!guild) {
            return res.status(404).json({ error: 'Guild not found or bot is not in this guild.' });
        }

        const channels = guild.channels.cache.map(channel => {
            const everyoneRole = guild.roles.everyone;
            const perms = channel.permissionsFor(everyoneRole);
            const isPrivate = !perms.has(PermissionsBitField.Flags.ViewChannel);

            return {
                id: channel.id,
                name: channel.name,
                type: channel.type,
                isPrivate: isPrivate,
                parentId: channel.parentId,
                position: channel.position
            };
        });

        const roles = guild.roles.cache.map(role => ({
            id: role.id,
            name: role.name,
            color: role.hexColor,
            position: role.position
        }));

        const members = guild.memberCount;

        res.json({
            id: guild.id,
            name: guild.name,
            iconURL: guild.iconURL() || 'https://cdn.discordapp.com/embed/avatars/0.png',
            memberCount: members,
            channels: channels,
            roles: roles,
        });

    } catch (error) {
        console.error('[Web] Error fetching guild details:', error);
        res.status(500).json({ error: 'Failed to retrieve guild details.' });
    }
});

// Reaction Roles
router.post('/guilds/:guildId/reaction-roles', async (req, res) => {
    try {
        const { guildId } = req.params;
        const { channelId, messageContent, emojis, roleIds } = req.body;

        if (!channelId || !messageContent || !emojis || !roleIds || emojis.length !== roleIds.length) {
            return res.status(400).json({ error: 'Invalid request body.' });
        }

        const guild = req.client.guilds.cache.get(guildId);
        if (!guild) {
            return res.status(404).json({ error: 'Guild not found.' });
        }

        const channel = guild.channels.cache.get(channelId);
        if (!channel || channel.type !== ChannelType.GuildText) {
            return res.status(404).json({ error: 'Text channel not found.' });
        }

        const embed = new EmbedBuilder()
            .setColor(0x0099ff)
            .setTitle('リアクションロール')
            .setDescription(messageContent);

        const sentMessage = await channel.send({ embeds: [embed] });
        const messageId = sentMessage.id;

        if (!reactionRoles.has(messageId)) {
            reactionRoles.set(messageId, new Map());
        }
        const emojiMap = reactionRoles.get(messageId);

        for (let i = 0; i < emojis.length; i++) {
            const emojiIdentifier = getEmojiIdentifier(emojis[i]);
            const roleId = roleIds[i];
            const role = guild.roles.cache.get(roleId);

            if (!role) {
                console.warn(`[Web] Role with ID ${roleId} not found in guild ${guildId}.`);
                continue;
            }

            emojiMap.set(emojiIdentifier, role.id);
            await sentMessage.react(emojiIdentifier).catch(console.error);
        }

        await saveReactionRoles();
        res.status(201).json({ success: true, messageId: messageId });

    } catch (error) {
        console.error('[Web] Error creating reaction role:', error);
        res.status(500).json({ error: 'Failed to create reaction role.' });
    }
});

// NG Words
router.get('/guilds/:guildId/ngwords', async (req, res) => {
    try {
        const { guildId } = req.params;
        const guildNgWords = ngWords.get(guildId) || [];
        res.json(guildNgWords.map(w => w.original));
    } catch (error) {
        console.error('[Web] Error fetching NG words:', error);
        res.status(500).json({ error: 'Failed to retrieve NG words.' });
    }
});

router.post('/guilds/:guildId/ngwords', async (req, res) => {
    try {
        const { guildId } = req.params;
        const { word } = req.body;

        if (!word || word.trim() === '') {
            return res.status(400).json({ error: 'NGワードが指定されていないか、空です。', field: 'word' });
        }

        const originalWord = word.trim();
        const normalizedWord = await normalizeJapanese(originalWord);
        let currentNgWords = ngWords.get(guildId) || [];

        if (currentNgWords.some(w => w.normalized === normalizedWord)) {
            return res.status(409).json({ error: `NGワード「${originalWord}」は既に登録されています。` });
        }

        currentNgWords.push({ original: originalWord, normalized: normalizedWord });
        ngWords.set(guildId, currentNgWords);
        await saveNgWords();

        res.status(201).json({ success: true, message: `NGワード「${originalWord}」を追加しました。`, addedWord: originalWord });

    } catch (error) {
        console.error('[Web] Error adding NG word:', error);
        res.status(500).json({ error: 'NGワードの追加に失敗しました。' });
    }
});

router.delete('/guilds/:guildId/ngwords/:word', async (req, res) => {
    try {
        const { guildId, word } = req.params;
        const originalWordToDelete = decodeURIComponent(word);

        let currentNgWords = ngWords.get(guildId) || [];

        const initialLength = currentNgWords.length;
        currentNgWords = currentNgWords.filter(w => w.original !== originalWordToDelete);

        if (currentNgWords.length === initialLength) {
            return res.status(404).json({ error: `NGワード「${originalWordToDelete}」が見つかりませんでした。` });
        }

        ngWords.set(guildId, currentNgWords);
        await saveNgWords();

        res.json({ success: true, message: `NGワード「${originalWordToDelete}」を削除しました。` });

    } catch (error) {
        console.error('[Web] Error deleting NG word:', error);
        res.status(500).json({ error: 'NGワードの削除に失敗しました。' });
    }
});

// Delete Messages
router.post('/guilds/:guildId/deletemessage', async (req, res) => {
    try {
        const { guildId } = req.params;
        const { channelId, userIdentifier, count } = req.body;

        if (!channelId || !count) {
            return res.status(400).json({ error: 'チャンネルIDと削除件数は必須です。' });
        }

        const guild = req.client.guilds.cache.get(guildId);
        if (!guild) {
            return res.status(404).json({ error: 'Guild not found.' });
        }

        const channel = guild.channels.cache.get(channelId);
        if (!channel || channel.type !== ChannelType.GuildText) {
            return res.status(404).json({ error: 'Text channel not found.' });
        }

        let targetUser = null;
        if (userIdentifier) {
            targetUser = guild.members.cache.get(userIdentifier);
            if (!targetUser) {
                targetUser = guild.members.cache.find(member => 
                    member.user.username.toLowerCase().includes(userIdentifier.toLowerCase())
                );
            }
            if (!targetUser) {
                return res.status(404).json({ error: `ユーザー「${userIdentifier}」が見つかりませんでした。` });
            }
        }

        const messages = await channel.messages.fetch({ limit: count });
        let filteredMessages = messages;
        if (targetUser) {
            filteredMessages = messages.filter(m => m.author.id === targetUser.id);
        }

        const deletedMessages = await channel.bulkDelete(filteredMessages, true);
        
        console.log(`[Web] ${req.user.username} deleted ${deletedMessages.size} messages from #${channel.name} in ${guild.name}`);
        res.json({ success: true, message: `${deletedMessages.size}件のメッセージを削除しました。` });

    } catch (error) {
        console.error('[Web] Error deleting messages:', error);
        res.status(500).json({ error: 'メッセージの削除に失敗しました。' });
    }
});

// Users
router.get('/guilds/:guildId/users', (req, res) => {
    try {
        const { guildId } = req.params;
        const query = req.query.q ? req.query.q.toLowerCase() : '';

        const guild = req.client.guilds.cache.get(guildId);
        if (!guild) {
            return res.status(404).json({ error: 'Guild not found.' });
        }

        guild.members.fetch().then(fetchedMembers => {
            const users = fetchedMembers.filter(member => 
                member.user.username.toLowerCase().includes(query) || 
                member.user.id.includes(query)
            ).map(member => ({
                id: member.user.id,
                username: member.user.username,
                discriminator: member.user.discriminator,
                tag: member.user.tag,
                avatarURL: member.user.displayAvatarURL(),
            }));
            res.json(users);
        }).catch(error => {
            console.error('[Web] Error fetching guild members:', error);
            res.status(500).json({ error: 'メンバーの取得に失敗しました。' });
        });

    } catch (error) {
        console.error('[Web] Error searching users:', error);
        res.status(500).json({ error: 'ユーザー検索に失敗しました。' });
    }
});

// Backup/Restore
router.post('/guilds/:guildId/backups', async (req, res) => {
    try {
        const { guildId } = req.params;
        const { backupName, backupMessages } = req.body;
        const userId = req.user.id;

        if (!backupName) {
            return res.status(400).json({ error: 'Backup name is required.' });
        }

        const guild = req.client.guilds.cache.get(guildId);
        if (!guild) {
            return res.status(404).json({ error: 'Guild not found.' });
        }

        await executeBackup({
            guild: guild,
            userId: userId,
            backupName: backupName,
            isAuto: false,
            backupMessages: !!backupMessages
        });

        res.status(201).json({ success: true, message: `バックアップ「${backupName}」の作成を開始しました。` });

    } catch (error) {
        console.error('[Web] Error creating backup:', error);
        res.status(500).json({ error: 'バックアップの作成に失敗しました。' });
    }
});

router.post('/guilds/:guildId/restore', async (req, res) => {
    try {
        const { guildId } = req.params;
        const { fileName } = req.body;
        const userId = req.user.id;

        if (!fileName) {
            return res.status(400).json({ error: 'File name is required.' });
        }

        const guild = req.client.guilds.cache.get(guildId);
        if (!guild) {
            return res.status(404).json({ error: 'Guild not found.' });
        }

        const mockInteraction = {
            guild: guild,
            user: { id: userId },
            options: {
                getString: (key) => {
                    if (key === 'file_name') return fileName;
                    return null;
                }
            },
            reply: async (options) => { console.log(`[Web-Restore] Reply: ${options.content}`); },
            followUp: async (options) => { console.log(`[Web-Restore] FollowUp: ${options.content}`); },
            deferReply: async () => { console.log('[Web-Restore] Reply deferred.'); }
        };

        await executeRestore(mockInteraction);

        res.json({ success: true, message: `バックアップ「${fileName}」からの復元を開始しました。` });

    } catch (error) {
        console.error('[Web] Error restoring backup:', error);
        res.status(500).json({ error: `復元に失敗しました: ${error.message}` });
    }
});

// Schedules
router.get('/guilds/:guildId/schedules', (req, res) => {
    const { guildId } = req.params;
    const schedulesForGuild = backupSchedules.get(guildId) || [];
    const serializableSchedules = schedulesForGuild.map(schedule => ({
        cronTime: schedule.cronTime,
        createdAt: schedule.createdAt,
        nextRun: CronExpressionParser.parse(schedule.cronTime, { tz: "Asia/Tokyo" }).next().toDate().toISOString(),
    }));
    res.json(serializableSchedules);
});

router.post('/guilds/:guildId/schedules', async (req, res) => {
    try {
        const { guildId } = req.params;
        const { cronTime } = req.body;
        const userId = req.user.id;

        if (!cron.validate(cronTime)) {
            return res.status(400).json({ error: 'Invalid cron format.' });
        }

        await addSchedule(req.client, guildId, cronTime, userId);
        res.status(201).json({ success: true, message: `スケジュール「${cronTime}」を追加しました。` });

    } catch (error) {
        console.error('[Web] Error adding schedule:', error);
        res.status(500).json({ error: `スケジュールの追加に失敗しました: ${error.message}` });
    }
});

router.delete('/guilds/:guildId/schedules', async (req, res) => {
    try {
        const { guildId } = req.params;
        const { cronTime } = req.body;

        await removeSchedule(guildId, cronTime);
        res.json({ success: true, message: `スケジュール「${cronTime}」を削除しました。` });

    } catch (error) {
        console.error('[Web] Error deleting schedule:', error);
        res.status(500).json({ error: `スケジュールの削除に失敗しました: ${error.message}` });
    }
});

module.exports = router;
