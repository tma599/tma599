// All JS code remains the same as the previous version.
        // Only the HTML and CSS have been updated for the new design.
        // The existing JS logic for fetching data and handling events is compatible.
        // --- State ---
        let allGuilds = [];
        let currentGuildData = null;
        let isFirstLoad = true;

        // --- DOM Elements ---
        const logLink = document.getElementById('log-link');
        const guildSelector = document.getElementById('guild-selector');
        const mainContent = document.getElementById('main-content');
        const guildView = document.getElementById('guild-view');
        const logView = document.getElementById('log-view');
        const welcomeView = document.getElementById('welcome-view');
        const serverInfoContainer = document.getElementById('server-info-container');
        const commandContainer = document.getElementById('command-container');
        const logContainer = document.getElementById('log-container');

        // --- View Management ---
        function showView(viewId) {
            document.querySelectorAll('#main-content .view').forEach(v => v.classList.remove('active'));
            document.getElementById(viewId)?.classList.add('active');
            
            logLink.classList.toggle('active', viewId === 'log-view');
            if (viewId !== 'guild-view') {
                 document.querySelectorAll('.guild-tab').forEach(t => t.classList.remove('active'));
            }
        }

        // --- API Functions ---
        async function fetchApi(url, options) {
            try {
                const response = await fetch(url, options);
                if (response.status === 401) {
                    window.location.reload();
                    return null;
                }
                if (!response.ok) {
                    const errorData = await response.json().catch(() => ({ error: '不明なエラーが発生しました。' }));
                    throw new Error(errorData.error);
                }
                return response.status === 204 ? {} : await response.json();
            } catch (error) {
                showToast(error.message, true);
                return null;
            }
        }

        // --- HTML Generation ---
        function generateServerInfoHTML(guild) {
            const sortedRoles = [...guild.roles].sort((a, b) => b.position - a.position);

            return `
                <div class="info-grid">
                    <div class="info-card">
                        <h3>サーバー情報</h3>
                        <ul><li><strong>メンバー数:</strong> ${guild.memberCount}</li></ul>
                    </div>
                    <div class="info-card" id="channel-list-card">
                        <h3>チャンネルリスト</h3>
                        <div id="channel-list-content"></div>
                    </div>
                    <div class="info-card">
                        <h3>ロール (${sortedRoles.length})</h3>
                        <div style="display:flex; flex-wrap:wrap;">
                            ${sortedRoles.map(r => {
                                const hex = r.color;
                                const bgColor = hex === '#000000' ? '#99aab5' : hex;
                                const r_val = parseInt(bgColor.slice(1, 3), 16);
                                const g_val = parseInt(bgColor.slice(3, 5), 16);
                                const b_val = parseInt(bgColor.slice(5, 7), 16);
                                const luminance = (0.299 * r_val + 0.587 * g_val + 0.114 * b_val);
                                const textColor = luminance > 150 ? '#2e3338' : '#ffffff';
                                return `<span class="role-pill" style="background-color:${bgColor}; color: ${textColor};">${r.name}</span>`;
                            }).join('')}
                        </div>
                    </div>
                </div>
            `;
        }

        function renderChannelList(guild) {
            const allChannels = [...guild.channels].sort((a, b) => a.position - b.position);

            const categories = allChannels.filter(c => c.type === 4).sort((a, b) => a.position - b.position);

            const getChannelIcon = (channel) => {
                let icon = '❓'; // Default for unknown types
                switch(channel.type) {
                    case 0: icon = '#'; break;        // GUILD_TEXT
                    case 2: icon = '🔊'; break;        // GUILD_VOICE
                    case 4: icon = '📁'; break;        // GUILD_CATEGORY (not directly listed, but for completeness)
                    case 5: icon = '📢'; break;        // GUILD_NEWS
                    case 6: icon = '🛒'; break;        // GUILD_STORE
                    case 10:                            // GUILD_NEWS_THREAD
                    case 11:                            // GUILD_PUBLIC_THREAD
                    case 12: icon = '💬'; break;       // GUILD_PRIVATE_THREAD
                    case 13: icon = '🎤'; break;       // GUILD_STAGE_VOICE
                    case 14: icon = '📖'; break;       // GUILD_DIRECTORY
                    case 15: icon = '📰'; break;       // GUILD_FORUM
                    case 16: icon = '🖼️'; break;       // GUILD_MEDIA
                }
                return icon;
            };

            const buildChannelItemHTML = (channel) => {
                const icon = getChannelIcon(channel);
                return `<li class="channel-item"><div>${icon} ${channel.name}</div></li>`;
            };

            let channelListHTML = '';

            // 1. Render channels without category first
            const topLevelChannels = allChannels.filter(c => (c.parentId === null || c.parentId === undefined) && c.type !== 4);
            if (topLevelChannels.length > 0) {
                channelListHTML += `
                    <div class="channel-group-uncategorized">
                        <div class="channel-category-name" data-category-id="uncategorized">
                            <svg class="icon" viewBox="0 0 24 24"><path d="M16.59 8.59L12 13.17 7.41 8.59 6 10l6 6 6-6z"/></svg>
                            カテゴリなしチャンネル
                        </div>
                        <ul class="channel-list-group" id="channel-list-uncategorized" style="display: block;">
                            ${topLevelChannels.map(buildChannelItemHTML).join('')}
                        </ul>
                    </div>
                `;
            }

            // 2. Render categorized channels
            categories.forEach(cat => {
                const channelsInCategory = allChannels.filter(c => c.parentId === cat.id)
                                                      .sort((a, b) => {
                                                          // Sort by type (text, voice, etc.) then by position
                                                          if (a.type !== b.type) {
                                                              return a.type - b.type;
                                                          }
                                                          return a.position - b.position;
                                                      });

                if (channelsInCategory.length > 0) {
                    channelListHTML += `
                        <div class="channel-category-group">
                            <div class="channel-category-name" data-category-id="${cat.id}">
                                <svg class="icon" viewBox="0 0 24 24"><path d="M16.59 8.59L12 13.17 7.41 8.59 6 10l6 6 6-6z"/></svg>
                                ${cat.name}
                            </div>
                            <ul class="channel-indent channel-list-group" id="channel-list-${cat.id}" style="display: block;">
                                ${channelsInCategory.map(buildChannelItemHTML).join('')}
                            </ul>
                        </div>
                    `;
                }
            });

            const channelListContent = document.getElementById('channel-list-content');
            if (channelListContent) {
                channelListContent.innerHTML = channelListHTML;
            }
        }

        function generateCommandTabsHTML() {
            return `
                <div id="command-tabs">
                    <button class="command-tab-button active" data-tab="backup">バックアップ</button>
                    <button class="command-tab-button" data-tab="reaction-role">リアクションロール</button>
                    <button class="command-tab-button" data-tab="ng-word">NGワード</button>
                    <button class="command-tab-button" data-tab="delete-message">メッセージ削除</button>
                </div>
                <div id="command-panes"></div>
            `;
        }
        
        // --- Main Functions ---
        async function initializeDashboard() {
            logLink.addEventListener('click', (e) => { e.preventDefault(); selectLogView(); });
            connectWebSocket();
            
            const guilds = await fetchApi('/api/guilds');
            if (!guilds) return;
            
            allGuilds = guilds;
            guildSelector.innerHTML = allGuilds.map(g => `
                <div class="guild-tab" data-guild-id="${g.id}" title="${g.name}">
                    <img src="${g.iconURL || 'https://cdn.discordapp.com/embed/avatars/0.png'}" alt="${g.name}">
                </div>
            `).join('');

            guildSelector.querySelectorAll('.guild-tab').forEach(tab => {
                tab.addEventListener('click', () => selectGuild(tab.dataset.guildId));
            });

            const initialId = window.location.hash.substring(1);
            if (initialId === 'logs') {
                selectLogView();
            } else if (initialId && allGuilds.some(g => g.id === initialId)) {
                selectGuild(initialId);
            } else {
                showView('welcome-view');
            }
        }

        function selectLogView() {
            showView('log-view');
            window.location.hash = 'logs';
        }

        async function selectGuild(guildId) {
            if (!guildId) return;
            
            showView('guild-view');
            window.location.hash = guildId;

            document.querySelectorAll('.guild-tab').forEach(t => t.classList.remove('active'));
            document.querySelector(`.guild-tab[data-guild-id="${guildId}"]`).classList.add('active');

            serverInfoContainer.innerHTML = "<div class='info-card'><h2>読み込み中...</h2></div>";
            commandContainer.innerHTML = "";

            const guildData = await fetchApi(`/api/guilds/${guildId}`);
            if (!guildData) return;
            
            currentGuildData = guildData;
            serverInfoContainer.innerHTML = generateServerInfoHTML(guildData);
            renderChannelList(guildData); // Call the new function here

            commandContainer.innerHTML = generateCommandTabsHTML();
            attachCommandTabListeners();
            openCommandTab('backup');
        }
        
        function attachCommandTabListeners() {
            document.querySelectorAll('.command-tab-button').forEach(button => {
                button.addEventListener('click', () => openCommandTab(button.dataset.tab));
            });
        }

        function openCommandTab(tabName) {
            document.querySelectorAll('.command-tab-button').forEach(b => b.classList.remove('active'));
            document.querySelector(`.command-tab-button[data-tab="${tabName}"]`).classList.add('active');
            
            const panesContainer = document.getElementById('command-panes');
            let html = '';
            let listenerAttacher = () => {};

            switch(tabName) {
                case 'backup':
                    html = getBackupPaneHTML();
                    listenerAttacher = attachBackupListeners;
                    break;
                case 'reaction-role':
                    html = getReactionRolePaneHTML();
                    listenerAttacher = attachReactionRoleListeners;
                    break;
                case 'ng-word':
                    html = getNgWordPaneHTML();
                    listenerAttacher = attachNgWordListeners;
                    break;
                case 'delete-message':
                    html = getDeleteMessagePaneHTML();
                    listenerAttacher = attachDeleteMessageListeners;
                    break;
            }
            
            panesContainer.innerHTML = `<div class="command-tab-pane active">${html}</div>`;
            listenerAttacher();
        }

        // --- WebSocket & Toast (no changes) ---
        function connectWebSocket() {
            const protocol = window.location.protocol === 'https' ? 'wss' : 'ws';
            const ws = new WebSocket(`${protocol}://${window.location.host}`);

            ws.onopen = () => {
                console.log('WebSocket connected');
                logContainer.innerHTML += '<div class="log-entry">[WebSocket] 接続が確立されました。</div>';
            };
            ws.onclose = () => {
                console.log('WebSocket closed. Reconnecting...');
                logContainer.innerHTML += '<div class="log-entry error">[WebSocket] 接続が切れました。5秒後に再接続します...</div>';
                setTimeout(connectWebSocket, 5000);
            };
            ws.onerror = (error) => {
                console.error('WebSocket error:', error);
                 logContainer.innerHTML += `<div class="log-entry error">[WebSocket] エラーが発生しました。</div>`;
            };
            ws.onmessage = (event) => {
                const { type, data } = JSON.parse(event.data);
                const entry = document.createElement('div');
                entry.className = `log-entry ${type}`;
                entry.textContent = data;
                
                const isScrolledToBottom = logContainer.scrollHeight - logContainer.clientHeight <= logContainer.scrollTop + 5;
                logContainer.appendChild(entry);
                if (isScrolledToBottom) {
                    logContainer.scrollTop = logContainer.scrollHeight;
                }
            };
        }
        function showToast(message, isError = false) {
            const toast = document.createElement('div');
            toast.textContent = message;
            Object.assign(toast.style, {
                position: 'fixed', bottom: '20px', left: '50%',
                transform: 'translateX(-50%)',
                backgroundColor: isError ? 'var(--danger-color)' : 'var(--success-color)',
                color: 'white', padding: '12px 24px', borderRadius: 'var(--border-radius)',
                zIndex: '1001', boxShadow: 'var(--shadow-lg)', fontWeight: '600'
            });
            document.body.appendChild(toast);
            setTimeout(() => toast.remove(), 3000);
        }

        // --- Pane HTML & Listeners ---
        function getBackupPaneHTML() {
            return `
                <div class="info-grid">
                    <div class="management-section">
                        <h3>新規バックアップ作成</h3>
                        <form id="backup-create-form">
                            <div class="form-group">
                                <label for="backup-name">バックアップ名</label>
                                <input type="text" id="backup-name" placeholder="例: my-backup-2025" required>
                            </div>
                            <div class="form-group">
                                <input type="checkbox" id="backup-messages" name="backup-messages" checked><label for="backup-messages" style="display:inline; margin-left: 8px;">メッセージもバックアップする</label>
                            </div>
                            <button type="submit" class="btn-primary">作成実行</button>
                        </form>
                    </div>
                    <div class="management-section">
                        <h3>バックアップから復元</h3>
                        <div class="restore-tabs" style="margin-bottom: 1em; border-bottom: 1px solid var(--background-tertiary); padding-bottom: 10px;">
                           <button class="tab-button active" data-restore-type="manual">手動</button>
                           <button class="tab-button" data-restore-type="auto">自動</button>
                        </div>
                        <form id="restore-form">
                            <div class="form-group">
                                <label for="restore-file-select">バックアップファイル</label>
                                <select id="restore-file-select" required>
                                    <option value="" disabled selected>復元するバックアップを選択...</option>
                                </select>
                            </div>
                            <button type="submit" class="btn-danger">復元実行</button>
                        </form>
                    </div>
                </div>
                <div class="management-section" style="margin-top: 1.5em;">
                    <h3>既存のバックアップ</h3>
                     <div class="backup-tabs" style="margin-bottom: 1em; border-bottom: 1px solid var(--background-tertiary); padding-bottom: 10px;">
                        <button class="tab-button active" data-backup-type="manual">手動</button>
                        <button class="tab-button" data-backup-type="auto">自動</button>
                    </div>
                    <table id="backups-table">
                       <thead><tr><th>ファイル名</th><th>作成日時</th><th>状態</th><th>操作</th></tr></thead>
                       <tbody></tbody>
                    </table>
                </div>
                <div class="management-section" style="margin-top: 1.5em;">
                    <h3>自動バックアップ設定</h3>
                    <form id="schedule-add-form">
                         <div class="form-group" style="display: flex; gap: 1em; align-items: flex-end; flex-wrap: wrap;">
                            <div style="flex-grow: 1; min-width: 120px;"><label for="schedule-day">曜日</label><select id="schedule-day"><option value="*">毎日</option><option value="0">日</option><option value="1">月</option><option value="2">火</option><option value="3">水</option><option value="4">木</option><option value="5">金</option><option value="6">土</option></select></div>
                            <div style="flex-grow: 1; min-width: 80px;"><label for="schedule-hour">時</label><input type="number" id="schedule-hour" min="0" max="23" required placeholder="0-23"></div>
                            <div style="flex-grow: 1; min-width: 80px;"><label for="schedule-minute">分</label><input type="number" id="schedule-minute" min="0" max="59" required placeholder="0-59"></div>
                            <button type="submit" class="btn-primary">スケジュール追加</button>
                        </div>
                    </form>
                    <table id="schedules-table">
                       <thead><tr><th>スケジュール (分 時 * * 曜日)</th><th>次回実行日時</th><th>操作</th></tr></thead>
                       <tbody></tbody>
                    </table>
                </div>
            `;
        }
        function attachBackupListeners() {
            const guildId = currentGuildData.id;
            
            // Listeners for the main backup list tabs
            document.querySelectorAll('.backup-tabs .tab-button').forEach(button => {
                button.addEventListener('click', () => {
                    document.querySelector('.backup-tabs .tab-button.active').classList.remove('active');
                    button.classList.add('active');
                    fetchBackups(guildId, button.dataset.backupType);
                });
            });

            // Listeners for the restore section tabs
            document.querySelectorAll('.restore-tabs .tab-button').forEach(button => {
                button.addEventListener('click', () => {
                    document.querySelector('.restore-tabs .tab-button.active').classList.remove('active');
                    button.classList.add('active');
                    fetchRestoreOptions(guildId, button.dataset.restoreType);
                });
            });

            document.getElementById('backup-create-form').addEventListener('submit', async e => {
                e.preventDefault();
                const result = await fetchApi(`/api/guilds/${guildId}/backups`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ backupName: document.getElementById('backup-name').value, backupMessages: document.getElementById('backup-messages').checked }) });
                if (result) { 
                    showToast('バックアップ作成を開始しました。'); 
                    fetchBackups(guildId, 'manual'); 
                    fetchRestoreOptions(guildId, 'manual');
                }
            });

            document.getElementById('restore-form').addEventListener('submit', async e => {
                e.preventDefault();
                const fileName = document.getElementById('restore-file-select').value;
                if (!fileName) {
                    showToast('復元するバックアップを選択してください。', true);
                    return;
                }
                if (!confirm(`本当にサーバーをバックアップ「${fileName}」から復元しますか？`)) return;
                const result = await fetchApi(`/api/guilds/${guildId}/restore`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ fileName }) });
                 if (result) showToast(`バックアップ「${fileName}」からの復元を開始しました。`);
            });

            document.getElementById('schedule-add-form').addEventListener('submit', async e => {
                e.preventDefault();
                const cronTime = `${document.getElementById('schedule-minute').value} ${document.getElementById('schedule-hour').value} * * ${document.getElementById('schedule-day').value}`;
                const result = await fetchApi(`/api/guilds/${guildId}/schedules`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ cronTime }) });
                if (result) { showToast('スケジュールを追加しました。'); fetchSchedules(guildId); }
            });

            // Initial data fetch
            fetchBackups(guildId, 'manual');
            fetchSchedules(guildId);
            fetchRestoreOptions(guildId, 'manual');
        }

        async function fetchBackups(guildId, type) {
            const backups = await fetchApi(`/api/backups?guildId=${guildId}&type=${type}`);
            const tableBody = document.getElementById('backups-table').querySelector('tbody');
            
            if (!backups) {
                tableBody.innerHTML = '<tr><td colspan="4">バックアップの読み込みに失敗しました。</td></tr>';
                return;
            }
            
            tableBody.innerHTML = backups.length === 0 ? '<tr><td colspan="4">バックアップはありません。</td></tr>' : backups.map(b => `
                <tr>
                    <td>${b.fileName}</td><td>${new Date(b.createdAt).toLocaleString()}</td>
                    <td style="font-weight:600; color: ${b.locked ? 'var(--warning-color)' : 'var(--success-color)'};">${b.locked ? 'ロック中' : '利用可能'}</td>
                    <td>
                        <button class="btn-danger" onclick="performBackupAction('${guildId}', 'delete', '${b.userId}', '${b.fileName}', '${type}')">削除</button>
                        <button class="btn-warning" onclick="performBackupAction('${guildId}', '${b.locked ? 'unlock' : 'lock'}', '${b.userId}', '${b.fileName}', '${type}')">${b.locked ? 'ロック解除' : 'ロック'}</button>
                    </td>
                </tr>`).join('');
        }

        async function fetchRestoreOptions(guildId, type) {
            const backups = await fetchApi(`/api/backups?guildId=${guildId}&type=${type}`);
            const restoreSelect = document.getElementById('restore-file-select');
            
            if (!backups) {
                restoreSelect.innerHTML = '<option value="" disabled selected>リストの読込失敗</option>';
                return;
            }

            restoreSelect.innerHTML = '<option value="" disabled selected>復元するバックアップを選択...</option>';
            backups.forEach(b => {
                const option = document.createElement('option');
                option.value = b.fileName;
                option.textContent = `${b.fileName} (${new Date(b.createdAt).toLocaleString()}) ${b.locked ? ' (ロック中)' : ''}`;
                option.disabled = b.locked;
                restoreSelect.appendChild(option);
            });
        }

        async function performBackupAction(guildId, action, userId, fileName, type) {
            if (action === 'delete' && !confirm(`本当にバックアップ「${fileName}」を削除しますか？`)) return;
            const result = await fetchApi('/api/backups/action', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action, userId, fileName }) });
            if (result) { 
                showToast(`バックアップ「${fileName}」を${action}しました。`); 
                fetchBackups(guildId, type);
                // Also refresh the restore options if the action was lock/unlock or delete
                const restoreType = document.querySelector('.restore-tabs .tab-button.active').dataset.restoreType;
                fetchRestoreOptions(guildId, restoreType);
            }
        }
        async function fetchSchedules(guildId) {
            const schedules = await fetchApi(`/api/guilds/${guildId}/schedules`);
            const tableBody = document.getElementById('schedules-table').querySelector('tbody');
            if (!schedules) { tableBody.innerHTML = '<tr><td colspan="3">スケジュールの読み込みに失敗しました。</td></tr>'; return; }
            tableBody.innerHTML = schedules.length === 0 ? '<tr><td colspan="3">スケジュールはありません。</td></tr>' : schedules.map(s => `
                <tr>
                    <td><code>${s.cronTime}</code></td><td>${new Date(s.nextRun).toLocaleString()}</td>
                    <td><button class="btn-danger" onclick="deleteSchedule('${guildId}', '${s.cronTime}')">削除</button></td>
                </tr>`).join('');
        }
        async function deleteSchedule(guildId, cronTime) {
            if (!confirm(`本当にスケジュール「${cronTime}」を削除しますか？`)) return;
            const result = await fetchApi(`/api/guilds/${guildId}/schedules`, { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ cronTime }) });
            if (result) { showToast('スケジュールを削除しました。'); fetchSchedules(guildId); }
        }
        function getReactionRolePaneHTML() {
            const { channels, roles } = currentGuildData;
            const textChannels = channels.filter(c => c.type === 0);
            return `
                <div class="management-section">
                    <h3>リアクションロール作成</h3>
                    <form id="reaction-role-form">
                        <div class="form-group">
                            <label for="rr-channel-id">チャンネル</label>
                            <select id="rr-channel-id" required>${textChannels.map(c => `<option value="${c.id}">${c.name}</option>`).join('')}</select>
                        </div>
                        <div class="form-group">
                            <label for="rr-message-content">メッセージ内容 (Embed)</label>
                            <textarea id="rr-message-content" rows="4" required></textarea>
                        </div>
                        <div id="rr-pairs-container" style="display: flex; flex-direction: column; gap: 1em;"></div>
                        <div style="margin-top: 1.5em;">
                            <button type="button" id="add-rr-pair-btn" class="btn-success" style="margin-right: 10px;">ペアを追加</button>
                            <button type="submit" class="btn-primary">作成</button>
                        </div>
                    </form>
                </div>`;
        }
        function attachReactionRoleListeners() {
            const guildId = currentGuildData.id;
            const roles = currentGuildData.roles;
            const pairsContainer = document.getElementById('rr-pairs-container');
            const addPair = () => {
                const div = document.createElement('div');
                div.className = 'rr-pair-group';
                div.style.cssText = `
                    display: flex; 
                    gap: 1em; 
                    align-items: center; 
                    border: 1px solid var(--background-tertiary); 
                    padding: 1em; 
                    border-radius: var(--border-radius);
                `;
                div.innerHTML = `
                    <div style="flex: 1;">
                        <label>絵文字</label>
                        <input type="text" class="rr-emoji" placeholder="例: 👍" required>
                    </div>
                    <div style="flex: 2;">
                        <label>ロール</label>
                        <select class="rr-role-id" required>${roles.map(r => `<option value="${r.id}">${r.name}</option>`).join('')}</select>
                    </div>
                    <button type="button" class="btn-danger remove-rr-pair-btn" style="align-self: flex-end;">削除</button>
                `;
                pairsContainer.appendChild(div);
                div.querySelector('.remove-rr-pair-btn').addEventListener('click', () => div.remove());
            };
            document.getElementById('add-rr-pair-btn').addEventListener('click', addPair);
            document.getElementById('reaction-role-form').addEventListener('submit', async e => {
                e.preventDefault();
                const body = { 
                    channelId: document.getElementById('rr-channel-id').value, 
                    messageContent: document.getElementById('rr-message-content').value, 
                    emojis: Array.from(document.querySelectorAll('.rr-emoji')).map(i => i.value), 
                    roleIds: Array.from(document.querySelectorAll('.rr-role-id')).map(s => s.value) 
                };
                if (body.emojis.length === 0) { 
                    showToast('少なくとも1つの絵文字とロールのペアを追加してください。', true); 
                    return; 
                }
                const result = await fetchApi(`/api/guilds/${guildId}/reaction-roles`, { 
                    method: 'POST', 
                    headers: { 'Content-Type': 'application/json' }, 
                    body: JSON.stringify(body) 
                });
                if (result) showToast('リアクションロールを作成しました。');
            });
            addPair();
        }
        function getNgWordPaneHTML() {
             return `
                <div class="management-section">
                    <h3>NGワード管理</h3>
                    <form id="ngword-add-form"><div class="form-group"><label for="ngword-input">NGワード追加</label><input type="text" id="ngword-input" placeholder="NGワードを入力" required></div><button type="submit" class="btn-primary">追加</button></form>
                </div>
                <div class="management-section" style="margin-top: 1.5em;">
                    <h3>現在のNGワードリスト</h3>
                    <table id="ngwords-table"><thead><tr><th>ワード</th><th>操作</th></tr></thead><tbody></tbody></table>
                </div>`;
        }
        function attachNgWordListeners() {
            const guildId = currentGuildData.id;
            document.getElementById('ngword-add-form').addEventListener('submit', async e => {
                e.preventDefault();
                const input = document.getElementById('ngword-input');
                const result = await fetchApi(`/api/guilds/${guildId}/ngwords`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ word: input.value }) });
                if (result) { showToast(`NGワード「${input.value}」を追加しました。`); input.value = ''; fetchNgWords(guildId); }
            });
            fetchNgWords(guildId);
        }
        async function fetchNgWords(guildId) {
            const words = await fetchApi(`/api/guilds/${guildId}/ngwords`);
            const tableBody = document.getElementById('ngwords-table').querySelector('tbody');
            if (!words) { tableBody.innerHTML = '<tr><td colspan="2">NGワードの読み込みに失敗しました。</td></tr>'; return; }
            tableBody.innerHTML = words.length === 0 ? '<tr><td colspan="2">NGワードはありません。</td></tr>' : words.map(word => `<tr><td>${word}</td><td><button class="btn-danger" onclick="deleteNgWord('${guildId}', '${encodeURIComponent(word)}')">削除</button></td></tr>`).join('');
        }
        async function deleteNgWord(guildId, word) {
            if (!confirm(`本当にNGワード「${decodeURIComponent(word)}」を削除しますか？`)) return;
            const result = await fetchApi(`/api/guilds/${guildId}/ngwords/${word}`, { method: 'DELETE' });
            if (result) { showToast('NGワードを削除しました。'); fetchNgWords(guildId); }
        }
        function getDeleteMessagePaneHTML() {
            const { channels } = currentGuildData;
            const textChannels = channels.filter(c => c.type === 0);
            return `
                 <div class="management-section">
                    <h3>メッセージ一括削除</h3>
                    <form id="delete-message-form">
                        <div class="form-group"><label for="dm-channel-id">チャンネル</label><select id="dm-channel-id" required>${textChannels.map(c => `<option value="${c.id}">${c.name}</option>`).join('')}</select></div>
                        <div class="form-group"><label for="dm-user-id">対象ユーザー (任意)</label><input type="text" id="dm-user-id" placeholder="ユーザーIDまたは名前で絞り込み"></div>
                        <div class="form-group"><label for="dm-count">削除するメッセージ件数 (最大100件)</label><input type="number" id="dm-count" min="1" max="100" value="50" required></div>
                        <button type="submit" class="btn-danger">削除実行</button>
                    </form>
                </div>`;
        }
        function attachDeleteMessageListeners() {
            const guildId = currentGuildData.id;
            document.getElementById('delete-message-form').addEventListener('submit', async e => {
                e.preventDefault();
                const result = await fetchApi(`/api/guilds/${guildId}/deletemessage`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ channelId: document.getElementById('dm-channel-id').value, userIdentifier: document.getElementById('dm-user-id').value, count: parseInt(document.getElementById('dm-count').value, 10) }) });
                if (result) showToast(result.message);
            });
        }

        // --- Initial Load ---
        document.addEventListener('DOMContentLoaded', initializeDashboard);
    