require('dotenv').config();

const fsp = require('fs/promises');
const path = require('path');
const cron = require('node-cron');
const util = require('util');
const { CronExpressionParser } = require('cron-parser');
const {
  Client,
  GatewayIntentBits,
  Events,
  REST,
  Routes,
  Collection,
  MessageFlags,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionsBitField,
  ChannelType,
} = require('discord.js');
const { loadCommands } = require('./utils/commandLoader');
const { getBackupDir, executeBackup } = require('./utils/backupManager');
const { executeRestore } = require('./utils/backupRestorer');
const { backupSchedules, saveSchedules, loadSchedules, addSchedule, removeSchedule } = require('./models/backupSchedules');
const { reactionRoles, loadReactionRoles, saveReactionRoles } = require('./models/reactionRoles');
const { initializeNgWords, ngWords, saveNgWords, normalizeJapanese } = require('./models/ngwords');
const WebSocket = require('ws');

const intents = [
  GatewayIntentBits.Guilds,
  GatewayIntentBits.GuildMembers,
  GatewayIntentBits.GuildMessages,
  GatewayIntentBits.MessageContent,
  GatewayIntentBits.GuildMessageReactions,
].filter(Boolean);

const client = new Client({
  intents: intents,
});

// --- Helper Functions ---
function getEmojiIdentifier(emoji) {
  // Matches custom emojis, including animated ones
  const customEmojiRegex = /<a?:\w+:(\d+)>/;
  const match = emoji.match(customEmojiRegex);
  if (match) {
    return match[1]; // Return the ID for custom emojis
  }
  return emoji; // Return the character for standard emojis
}

client.commands = new Collection();

const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);
const USE_GLOBAL = false;

const schedulesFilePath = path.join(__dirname, 'schedules.json');

// --- Event Handlers ---
client.once(Events.ClientReady, async () => {
  const originalLog = console.log;
  const originalError = console.error;
  const originalWarn = console.warn;

  // Start the web server only after the bot is ready
  const server = app.listen(PORT, () => {
    originalLog(`[Web] ダッシュボードが http://localhost:${PORT} で起動しました。`);
  });

  const wss = new WebSocket.Server({ server });

  wss.on('connection', (ws) => {
      originalLog('[WebSocket] Client connected');
      ws.on('close', () => {
          originalLog('[WebSocket] Client disconnected');
      });
      ws.on('error', (error) => {
          originalError('[WebSocket] Error:', error);
      });
  });

  // Function to broadcast data to all connected WebSocket clients
  function broadcastLog(data, type = 'log') {
      const message = JSON.stringify({ type, data });
      wss.clients.forEach(client => {
          if (client.readyState === WebSocket.OPEN) {
              client.send(message);
          }
      });
  }

  client.broadcastGuildUpdate = (guildId, guildData) => {
      const message = JSON.stringify({ type: 'guildUpdate', guildId, guildData });
      wss.clients.forEach(client => {
          if (client.readyState === WebSocket.OPEN) {
              client.send(message);
          }
      });
  };

  // Override console.log, console.error, etc. to also send to WebSocket
  console.log = (...args) => {
      const message = util.format(...args);
      originalLog.apply(console, args);
      broadcastLog(message, 'log');
  };

  console.error = (...args) => {
      const message = util.format(...args);
      originalError.apply(console, args);
      broadcastLog(message, 'error');
  };

  console.warn = (...args) => {
      const message = util.format(...args);
      originalWarn.apply(console, args);
      broadcastLog(message, 'warn');
  };
  
  console.log('--------------------------------------------------');
  console.log(`[起動] ${client.user.tag} が起動しました。`);
  console.log('[起動] 各種モジュールを初期化します。');
  try {
    await initializeNgWords();
    console.log('[DEBUG] Attempting to load schedules...');
    await loadSchedules(client);
    console.log(`[DEBUG] Schedules loaded. Current backupSchedules Map size: ${backupSchedules.size}`);
    await loadReactionRoles();
    
    console.log('[起動] スラッシュコマンドを登録します。');
    await loadCommands(client);
    const commandsToRegister = Array.from(client.commands.values()).map((cmd) => cmd.data.toJSON());

    if (USE_GLOBAL) {
      await rest.put(Routes.applicationCommands(client.user.id), {
        body: commandsToRegister,
      });
      console.log('[起動] グローバルスラッシュコマンドを登録しました。');
    } else {
      for (const guild of client.guilds.cache.values()) {
        await guild.commands.set(commandsToRegister);
        console.log(`[起動] ギルド "${guild.name}" にスラッシュコマンドを登録しました。`);
      }
    }
    console.log('[起動] スラッシュコマンドの登録が完了しました。');
    console.log('--------------------------------------------------');
  } catch (err) {
    console.error('[エラー] 起動処理中にエラーが発生しました。', err);
  }
});

if (!process.env.DISCORD_TOKEN) {
  console.error('DISCORD_TOKENが設定されていません。');
  process.exit(1);
}

client.on(Events.GuildCreate, async (guild) => {
  if (USE_GLOBAL) return;
  try {
    const commandsToRegister = Array.from(client.commands.values()).map((cmd) => cmd.data.toJSON());
    await guild.commands.set(commandsToRegister);
    console.log(`[参加] 新しいギルド "${guild.name}" に参加し、コマンドを登録しました。`);
  } catch (err) {
    console.error(`[エラー] 新しいギルド "${guild.name}" でのコマンド登録に失敗しました。`, err);
  }
});

client.on(Events.MessageUpdate, async (oldMessage, newMessage) => {
    if (newMessage.author.bot || newMessage.system) return;

    // NGワードチェック (編集後)
    const guildId = newMessage.guild.id;
    const guildNgWords = ngWords.get(guildId) || [];

    if (guildNgWords.length > 0) {
        const normalizedContent = await normalizeJapanese(newMessage.content);
        for (const ngWord of guildNgWords) {
            if (normalizedContent.includes(ngWord.normalized)) {
                try {
                    await newMessage.delete();
                    const sentMsg = await newMessage.channel.send(`${newMessage.author}, あなたのメッセージにはNGワードが含まれていたため、削除されました。`);
                    setTimeout(() => sentMsg.delete().catch(console.error), 5000);
                    console.log(`[NGワード] ユーザー ${newMessage.author.tag} の編集後メッセージを削除しました。理由: NGワード「${ngWord.original}」を検出。`);
                } catch (error) {
                    console.error('[NGワード] 編集後メッセージの削除中にエラーが発生しました:', error);
                }
                return;
            }
        }
    }

  if (oldMessage.content === newMessage.content) {
    return;
  }
  if (oldMessage.partial) {
    try {
      oldMessage = await oldMessage.fetch();
    } catch (error) {
      console.error(
        `[エラー] 編集前のメッセージの取得に失敗しました (ID: ${oldMessage.id})`,
        error
      );
      return;
    }
  }
  const userTag = newMessage.author.tag;
  const userId = newMessage.author.id;
  const channelName = newMessage.channel.name;
  const oldContent = oldMessage.content || '[内容なし]';
  const newContent = newMessage.content || '[内容なし]';
  const messageURL = `https://discord.com/channels/${newMessage.guildId}/${newMessage.channelId}/${newMessage.id}`;
  console.log('--------------------------------------------------');
  console.log('[メッセージ編集検知]');
  console.log(`ユーザー: ${userTag} (ID: ${userId})`);
  console.log(`チャンネル: #${channelName}`);
  console.log(`編集前の内容: ${oldContent}`);
  console.log(`編集後の内容: ${newContent}`);
  console.log(`メッセージURL: ${messageURL}`);
  console.log('--------------------------------------------------');
});

client.on(Events.MessageDelete, async (message) => {
  if (message.partial) {
    console.log('[メッセージ削除検知] キャッシュ外のメッセージが削除されました。');
    return;
  }
  const userTag = message.author ? message.author.tag : '不明なユーザー';
  const userId = message.author ? message.author.id : '不明なID';
  const channelName = message.channel ? message.channel.name : '不明なチャンネル';
  const channelId = message.channel ? message.channel.id : '不明なID';
  const deletedContent = message.content || '[内容なし]';
  const messageId = message.id;
  const messageURL = `https://discord.com/channels/${message.guildId}/${message.channelId}/${message.id}`;
  let attachmentURLs = [];
  if (message.attachments.size > 0) {
    attachmentURLs = message.attachments.map((attachment) => attachment.url);
  }
  console.log('--------------------------------------------------');
  console.log('[メッセージ削除検知]');
  console.log(`送信者: ${userTag} (ID: ${userId})`);
  console.log(`チャンネル: #${channelName} (ID: ${channelId})`);
  console.log(`削除されたメッセージ内容: ${deletedContent}`);
  if (attachmentURLs.length > 0) {
    console.log(`添付ファイルURL: ${attachmentURLs.join(', ')}`);
  }
  console.log(`メッセージID: ${messageId}`);
  console.log(`メッセージURL: ${messageURL}`);
  console.log('--------------------------------------------------');
});

client.on(Events.MessageReactionAdd, async (reaction, user) => {
  if (user.bot) return;

  if (reaction.partial) {
    try {
      await reaction.fetch();
    } catch (error) {
      console.error('[リアクション] リアクションのフェッチ中にエラーが発生しました:', error);
      return;
    }
  }

  const messageId = reaction.message.id;
  const emojiIdentifier = reaction.emoji.id || reaction.emoji.name;

  if (reactionRoles.has(messageId)) {
    const emojiMap = reactionRoles.get(messageId);
    if (emojiMap.has(emojiIdentifier)) {
      const roleId = emojiMap.get(emojiIdentifier);
      const member = reaction.message.guild.members.cache.get(user.id);
      if (member) {
        try {
          const role = reaction.message.guild.roles.cache.get(roleId);
          if (role) {
            await member.roles.add(role);
            console.log(
              `[リアクションロール] ユーザー ${user.tag} にロール ${role.name} を付与しました。`
            );
          } else {
            console.warn(`[リアクションロール] ロールID ${roleId} が見つかりません。`);
          }
        } catch (error) {
          console.error('[リアクションロール] ロールの付与中にエラーが発生しました:', error);
        }
      }
    }
  }
});

client.on(Events.MessageReactionRemove, async (reaction, user) => {
  if (user.bot) return;

  if (reaction.partial) {
    try {
      await reaction.fetch();
    } catch (error) {
      console.error('[リアクション] リアクションのフェッチ中にエラーが発生しました:', error);
      return;
    }
  }

  const messageId = reaction.message.id;
  const emojiIdentifier = reaction.emoji.id || reaction.emoji.name;

  if (reactionRoles.has(messageId)) {
    const emojiMap = reactionRoles.get(messageId);
    if (emojiMap.has(emojiIdentifier)) {
      const roleId = emojiMap.get(emojiIdentifier);
      const member = reaction.message.guild.members.cache.get(user.id);
      if (member) {
        try {
          const role = reaction.message.guild.roles.cache.get(roleId);
          if (role) {
            await member.roles.remove(role);
            console.log(
              `[リアクションロール] ユーザー ${user.tag} からロール ${role.name} を削除しました。`
            );
          } else {
            console.warn(`[リアクションロール] ロールID ${roleId} が見つかりません。`);
          }
        } catch (error) {
          console.error('[リアクションロール] ロールの削除中にエラーが発生しました:', error);
        }
      }
    }
  }
});

const reactionRoleSetup = new Map();

// This is the single, corrected MessageCreate handler
client.on(Events.MessageCreate, async (message) => {
    if (message.author.bot || !message.guild) return;

    // NGワードチェック
    const guildId = message.guild.id;
    const guildNgWords = ngWords.get(guildId) || [];

    if (guildNgWords.length > 0) {
        const normalizedContent = await normalizeJapanese(message.content);
        for (const ngWord of guildNgWords) {
            if (normalizedContent.includes(ngWord.normalized)) {
                try {
                    await message.delete();
                    const sentMsg = await message.channel.send(`${message.author}, あなたのメッセージにはNGワードが含まれていたため、削除されました。`);
                    // メッセージを5秒後に削除
                    setTimeout(() => sentMsg.delete().catch(console.error), 5000);
                    console.log(`[NGワード] ユーザー ${message.author.tag} のメッセージを削除しました。理由: NGワード「${ngWord.original}」を検出。`);
                } catch (error) {
                    console.error('[NGワード] メッセージの削除中にエラーが発生しました:', error);
                }
                return; // NGワードを検出したら以降の処理はしない
            }
        }
    }

    // リアクションロール設定用のチャンネルでの処理
    if (message.channel.name.startsWith('rr-config-') && message.channel.name.endsWith(message.author.id)) {
        const configUserId = message.author.id;
        const setup = reactionRoleSetup.get(configUserId);
        let setupComplete = false;

        try {
            if (!setup) {
                const targetChannel = message.guild.channels.cache.find(c => c.name === message.content);
                if (!targetChannel || targetChannel.type !== ChannelType.GuildText) {
                    return message.reply('**有効なテキストチャンネル名を指定してください。**');
                }
                reactionRoleSetup.set(configUserId, { step: 1, channel: targetChannel });
                return message.reply('Botがメッセージを出力するチャンネル名を入力してください。');
            }

            switch (setup.step) {
                case 1:
                    setup.message = message.content;
                    setup.step = 2;
                    return message.reply('**追加する絵文字を入力してください(複数個やる場合は半角スペースを挟んでください)**');
                case 2:
                    setup.emojis = message.content.split(' ');
                    setup.step = 3;
                    return message.reply('**リアクションに結びつけるロール名を入力してください(絵文字との結びつけは左から順に、半角スペースで区切ってください)**');
                case 3:
                    setup.roles = message.content.split(' ');
                    if (setup.emojis.length !== setup.roles.length) {
                        await message.reply('**絵文字とロールの数が一致しません。最初からやり直してください。このチャンネルは5秒後に削除されます。**');
                        setupComplete = true;
                        return;
                    }

                    await message.reply('**入力された設定でコマンドを実行します…**');

                    const targetChannel = setup.channel;
                    
                    const embedMessage = new EmbedBuilder()
                        .setColor(0x0099ff)
                        .setDescription(setup.message);

                    const sentMessage = await targetChannel.send({ embeds: [embedMessage] });
                    const messageId = sentMessage.id;

                    if (!reactionRoles.has(messageId)) {
                        reactionRoles.set(messageId, new Map());
                    }
                    const emojiMap = reactionRoles.get(messageId);

                    for (let i = 0; i < setup.emojis.length; i++) {
                        const emoji = setup.emojis[i];
                        const roleName = setup.roles[i];
                        const role = message.guild.roles.cache.find((r) => r.name === roleName);

                        if (!role) {
                            await message.reply(`**ロール「${roleName}」が見つかりません。このロールはスキップします。**`);
                            continue;
                        }

                        const emojiIdentifier = getEmojiIdentifier(emoji);
                        emojiMap.set(emojiIdentifier, role.id);
                        await sentMessage.react(emoji).catch(err => {
                            console.error(`Failed to react with ${emoji}:`, err);
                            message.channel.send(`**絵文字 ${emoji} のリアクションに失敗しました。ボットがこの絵文字にアクセスできない可能性があります。**`);
                        });
                    }

                    await saveReactionRoles();
                    await message.reply('**実行されました。このチャンネルは5秒後に削除されます。**');
                    setupComplete = true;
                    break;
            }
        } catch (error) {
            console.error('リアクションロールの設定中にエラーが発生しました:', error);
            await message.reply('**エラーが発生したため、設定を中止します。このチャンネルは5秒後に削除されます。**').catch(console.error);
            setupComplete = true;
        } finally {
            if (setupComplete) {
                reactionRoleSetup.delete(configUserId);
                setTimeout(() => message.channel.delete().catch(console.error), 5000);
            }
        }
    }
});

function logCommand(interaction) {
  const user = interaction.user;
  const commandName = interaction.commandName;
  const options = interaction.options.data.map((opt) => `${opt.name}: ${opt.value}`).join(' ');
  const guild = interaction.guild;
  console.log(
    `[コマンド実行] ユーザー: ${user.tag} (ID: ${user.id}) | コマンド: /${commandName} ${options} | サーバー: ${guild.name} (ID: ${guild.id})`
  );
}

client.on(Events.InteractionCreate, async (interaction) => {
  if (interaction.isAutocomplete()) {
    const command = interaction.client.commands.get(interaction.commandName);
    if (!command || !command.autocomplete) return;
    try {
      await command.autocomplete(interaction);
    } catch (error) {
      console.error('[エラー] オートコンプリートの処理中にエラーが発生しました。', error);
    }
    return;
  }

  if (!interaction.isChatInputCommand()) return;
  if (!interaction.guild || !interaction.inCachedGuild()) {
    return interaction.reply({
      content: 'このコマンドはサーバー内でのみ使用できます。',
      flags: MessageFlags.Ephemeral,
    });
  }

  logCommand(interaction);
  const { commandName } = interaction;

  try {
    const command = client.commands.get(commandName);
    if (command) {
      await command.execute(interaction);
    } else {
      console.error(`[エラー] 未知のコマンドが実行されました: ${commandName}`);
      await interaction.reply({ content: '不明なコマンドです。', flags: MessageFlags.Ephemeral });
    }
  } catch (error) {
    console.error('[エラー] コマンド実行中に予期せぬエラーが発生しました。', error);
    const replyOptions = {
      content: 'コマンドの実行中に予期せぬエラーが発生しました。',
      flags: MessageFlags.Ephemeral,
    };
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp(replyOptions);
    } else {
      await interaction.reply(replyOptions);
    }
  }
});

process.on('unhandledRejection', (reason) => {
  console.error('[エラー] 未処理のPromise rejection:', reason);
});

// --- Web Dashboard with Auth ---
const express = require('express');
const session = require('express-session');
const passport = require('passport');
const DiscordStrategy = require('passport-discord').Strategy;
const FileStore = require('session-file-store')(session);

// Check for required environment variables
if (!process.env.DISCORD_CLIENT_ID || !process.env.DISCORD_CLIENT_SECRET || !process.env.SESSION_SECRET) {
    console.error('[Web] Error: Required environment variables for dashboard authentication are missing.');
    console.error('[Web] Please set DISCORD_CLIENT_ID, DISCORD_CLIENT_SECRET, and SESSION_SECRET in your .env file.');
    process.exit(1);
}

const app = express();
const PORT = process.env.PORT || 3000;

// --- Passport & Session Setup ---
passport.serializeUser((user, done) => {
  done(null, user);
});

passport.deserializeUser((obj, done) => {
  done(null, obj);
});

passport.use(new DiscordStrategy({
    clientID: process.env.DISCORD_CLIENT_ID,
    clientSecret: process.env.DISCORD_CLIENT_SECRET,
    callbackURL: `http://localhost:${PORT}/auth/discord/callback`,
    scope: ['identify', 'guilds'] // We need 'guilds' to check if the user is an admin
}, (accessToken, refreshToken, profile, done) => {
    // Here you could, for example, check if the user is the bot owner
    // For now, we'll just log them in.
    return done(null, profile);
}));

app.use(session({
    store: new FileStore({ path: './.sessions', ttl: 86400 }), // 1 day
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
        maxAge: 1000 * 60 * 60 * 24 // 1 day
    }
}));

app.use(passport.initialize());
app.use(passport.session());

// Middleware to parse JSON bodies
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Middleware to ensure the user is authenticated for web pages
function ensureAuth(req, res, next) {
    if (req.isAuthenticated()) {
        return next();
    }
    // APIリクエストの場合はJSONエラーを返す
    if (req.xhr || req.headers.accept.indexOf('json') > -1) {
        return res.status(401).json({ error: 'Unauthorized. Please log in again.' });
    }
    res.redirect('/'); // Redirect to login page if not authenticated
}

// Middleware to ensure the user is authenticated for API requests
function ensureApiAuth(req, res, next) {
    if (req.isAuthenticated()) {
        return next();
    }
    // APIリクエストの場合は常にJSONを返す
    res.status(401).json({ error: 'Unauthorized. Please log in again.' });
}

// --- Auth Routes ---
app.get('/auth/discord', passport.authenticate('discord'));

app.get('/auth/discord/callback', passport.authenticate('discord', {
    failureRedirect: '/' // Redirect back to login page on failure
}), (req, res) => {
    res.redirect('/'); // Successful login redirects to the dashboard
});

app.get('/auth/logout', (req, res) => {
    req.logout(() => {
        res.redirect('/');
    });
});

// --- API & Dashboard Routes (Protected) ---
app.get('/api/backups', ensureApiAuth, async (req, res) => {
  const backupsPath = path.join(__dirname, 'backups');
  const targetGuildId = req.query.guildId; // Get guildId from query parameter
  const backupType = req.query.type; // 'auto' or 'manual'

  try {
    const userFolders = await fsp.readdir(backupsPath, { withFileTypes: true });
    const allBackups = [];

    for (const userFolder of userFolders) {
      if (userFolder.isDirectory()) {
        const userId = userFolder.name;
        const userBackupDir = getBackupDir(userId);
        try {
          const files = await fsp.readdir(userBackupDir);
          let backupFiles = files.filter(file => file.endsWith('.json'));

          if (backupType === 'auto') {
            backupFiles = backupFiles.filter(file => file.startsWith('auto_'));
          } else if (backupType === 'manual') {
            backupFiles = backupFiles.filter(file => !file.startsWith('auto_'));
          }
          
          for (const file of backupFiles) {
             const filePath = path.join(userBackupDir, file);
             const data = await fsp.readFile(filePath, 'utf-8');
             const json = JSON.parse(data);

             // Filter by guildId if provided
             if (targetGuildId && json.serverId !== targetGuildId) {
                 continue;
             }

             allBackups.push({
                 userId: userId,
                 fileName: file,
                 serverName: json.serverName || 'N/A',
                 createdAt: json.createdAt || 'N/A',
                 locked: json.locked || false,
                 guildId: json.serverId || 'N/A', // Include guildId in response
             });
          }
        } catch (err) {
          console.error(`[Web] Could not read backups for user ${userId}:`, err);
        }
      }
    }
    res.json(allBackups);
  } catch (error) {
    console.error('[Web] Error fetching backups:', error);
    if (error.code === 'ENOENT') {
        return res.json([]);
    }
    res.status(500).json({ error: 'Failed to retrieve backups.' });
  }
});

// API Endpoint to perform actions on backups
app.post('/api/backups/action', ensureApiAuth, async (req, res) => {
    const { action, userId, fileName } = req.body;

    if (!action || !userId || !fileName) {
        return res.status(400).json({ error: 'Missing required parameters.' });
    }

    const backupDir = getBackupDir(userId);
    const backupFilePath = path.join(backupDir, fileName);

    try {
        // Check if the file exists
        await fsp.access(backupFilePath);
        const fileData = await fsp.readFile(backupFilePath, 'utf-8');
        const backupJson = JSON.parse(fileData);

        switch (action) {
            case 'lock':
                backupJson.locked = true;
                await fsp.writeFile(backupFilePath, JSON.stringify(backupJson, null, 2));
                console.log(`[Web] User ${req.user.username} locked backup ${fileName}`);
                res.json({ success: true, message: `File ${fileName} locked.` });
                break;
            case 'unlock':
                backupJson.locked = false;
                await fsp.writeFile(backupFilePath, JSON.stringify(backupJson, null, 2));
                console.log(`[Web] User ${req.user.username} unlocked backup ${fileName}`);
                res.json({ success: true, message: `File ${fileName} unlocked.` });
                break;
            case 'delete':
                if (backupJson.locked) {
                    return res.status(403).json({ error: 'Cannot delete a locked file.' });
                }
                await fsp.unlink(backupFilePath);
                console.log(`[Web] User ${req.user.username} deleted backup ${fileName}`);
                res.json({ success: true, message: `File ${fileName} deleted.` });
                break;
            default:
                res.status(400).json({ error: 'Invalid action.' });
        }
    } catch (error) {
        if (error.code === 'ENOENT') {
            return res.status(404).json({ error: `File ${fileName} not found.` });
        }
        console.error(`[Web] Error performing action ${action} on ${fileName}:`, error);
        res.status(500).json({ error: `Failed to perform action on ${fileName}.` });
  }
});

// API Endpoint to get all guilds the bot is in
app.get('/api/guilds', ensureApiAuth, (req, res) => {
    try {
        const guilds = client.guilds.cache.map(guild => ({
            id: guild.id,
            name: guild.name,
            iconURL: guild.iconURL(),
            memberCount: guild.memberCount,
        }));
        res.json(guilds);
    } catch (error) {
        console.error('[Web] Error fetching guilds:', error);
        res.status(500).json({ error: 'Failed to retrieve guilds.' });
    }
});

// API Endpoint to get detailed information for a specific guild
app.get('/api/guilds/:guildId', ensureApiAuth, (req, res) => {
    try {
        const guildId = req.params.guildId;
        const guild = client.guilds.cache.get(guildId);

        if (!guild) {
            return res.status(404).json({ error: 'Guild not found or bot is not in this guild.' });
        }

        const channels = guild.channels.cache.map(channel => {
            const everyoneRole = guild.roles.everyone;
            const perms = channel.permissionsFor(everyoneRole);
            const isPrivate = !perms.has(PermissionsBitField.Flags.ViewChannel);

            return {
                id: channel.id,
                name: channel.name,
                type: channel.type,
                isPrivate: isPrivate,
                parentId: channel.parentId,
                position: channel.position
            };
        });

        const roles = guild.roles.cache.map(role => ({
            id: role.id,
            name: role.name,
            color: role.hexColor,
            position: role.position
        }));

        const members = guild.memberCount; // Total member count

        res.json({
            id: guild.id,
            name: guild.name,
            iconURL: guild.iconURL() || 'https://cdn.discordapp.com/embed/avatars/0.png',
            memberCount: members,
            channels: channels,
            roles: roles,
        });

    } catch (error) {
        console.error('[Web] Error fetching guild details:', error);
        res.status(500).json({ error: 'Failed to retrieve guild details.' });
    }
});

// API Endpoint to create a reaction role
app.post('/api/guilds/:guildId/reaction-roles', ensureApiAuth, async (req, res) => {
    try {
        const { guildId } = req.params;
        const { channelId, messageContent, emojis, roleIds } = req.body;

        if (!channelId || !messageContent || !emojis || !roleIds || emojis.length !== roleIds.length) {
            return res.status(400).json({ error: 'Invalid request body.' });
        }

        const guild = client.guilds.cache.get(guildId);
        if (!guild) {
            return res.status(404).json({ error: 'Guild not found.' });
        }

        const channel = guild.channels.cache.get(channelId);
        if (!channel || channel.type !== ChannelType.GuildText) {
            return res.status(404).json({ error: 'Text channel not found.' });
        }

        const embed = new EmbedBuilder()
            .setColor(0x0099ff)
            .setTitle('リアクションロール')
            .setDescription(messageContent);

        const sentMessage = await channel.send({ embeds: [embed] });
        const messageId = sentMessage.id;

        if (!reactionRoles.has(messageId)) {
            reactionRoles.set(messageId, new Map());
        }
        const emojiMap = reactionRoles.get(messageId);

        for (let i = 0; i < emojis.length; i++) {
            const emojiIdentifier = getEmojiIdentifier(emojis[i]);
            const roleId = roleIds[i];
            const role = guild.roles.cache.get(roleId);

            if (!role) {
                console.warn(`[Web] Role with ID ${roleId} not found in guild ${guildId}.`);
                continue;
            }

            emojiMap.set(emojiIdentifier, role.id);
            await sentMessage.react(emojiIdentifier).catch(console.error);
        }

        await saveReactionRoles();
        res.status(201).json({ success: true, messageId: messageId });

    } catch (error) {
        console.error('[Web] Error creating reaction role:', error);
        res.status(500).json({ error: 'Failed to create reaction role.' });
    }
});

// API Endpoint to get NG words for a specific guild
app.get('/api/guilds/:guildId/ngwords', ensureApiAuth, async (req, res) => {
    try {
        const { guildId } = req.params;
        const guildNgWords = ngWords.get(guildId) || [];
        // クライアントには元の単語だけを送る
        res.json(guildNgWords.map(w => w.original));
    } catch (error) {
        console.error('[Web] Error fetching NG words:', error);
        res.status(500).json({ error: 'Failed to retrieve NG words.' });
    }
});

// API Endpoint to add an NG word for a specific guild
app.post('/api/guilds/:guildId/ngwords', ensureApiAuth, async (req, res) => {
    try {
        const { guildId } = req.params;
        const { word } = req.body;

        if (!word || word.trim() === '') {
            return res.status(400).json({ error: 'NGワードが指定されていないか、空です。', field: 'word' });
        }

        const originalWord = word.trim();
        const normalizedWord = await normalizeJapanese(originalWord);
        let currentNgWords = ngWords.get(guildId) || [];

        // 既に同じ単語（正規化後）が登録されているかチェック
        if (currentNgWords.some(w => w.normalized === normalizedWord)) {
            return res.status(409).json({ error: `NGワード「${originalWord}」は既に登録されています。` });
        }

        currentNgWords.push({ original: originalWord, normalized: normalizedWord });
        ngWords.set(guildId, currentNgWords);
        await saveNgWords();

        res.status(201).json({ success: true, message: `NGワード「${originalWord}」を追加しました。`, addedWord: originalWord });

    } catch (error) {
        console.error('[Web] Error adding NG word:', error);
        res.status(500).json({ error: 'NGワードの追加に失敗しました。' });
    }
});

// API Endpoint to delete an NG word for a specific guild
app.delete('/api/guilds/:guildId/ngwords/:word', ensureApiAuth, async (req, res) => {
    try {
        const { guildId, word } = req.params;
        const originalWordToDelete = decodeURIComponent(word); // URLエンコードされたワードをデコード

        let currentNgWords = ngWords.get(guildId) || [];

        const initialLength = currentNgWords.length;
        // 元の単語を元にフィルタリング
        currentNgWords = currentNgWords.filter(w => w.original !== originalWordToDelete);

        if (currentNgWords.length === initialLength) {
            return res.status(404).json({ error: `NGワード「${originalWordToDelete}」が見つかりませんでした。` });
        }

        ngWords.set(guildId, currentNgWords);
        await saveNgWords();

        res.json({ success: true, message: `NGワード「${originalWordToDelete}」を削除しました。` });

    } catch (error) {
        console.error('[Web] Error deleting NG word:', error);
        res.status(500).json({ error: 'NGワードの削除に失敗しました。' });
    }
});

// API Endpoint to delete messages
app.post('/api/guilds/:guildId/deletemessage', ensureApiAuth, async (req, res) => {
    try {
        const { guildId } = req.params;
        const { channelId, userIdentifier, count } = req.body; // userIdentifierに変更

        if (!channelId || !count) {
            return res.status(400).json({ error: 'チャンネルIDと削除件数は必須です。' });
        }

        const guild = client.guilds.cache.get(guildId);
        if (!guild) {
            return res.status(404).json({ error: 'Guild not found.' });
        }

        const channel = guild.channels.cache.get(channelId);
        if (!channel || channel.type !== ChannelType.GuildText) {
            return res.status(404).json({ error: 'Text channel not found.' });
        }

        let targetUser = null;
        if (userIdentifier) {
            // ユーザーIDで検索
            targetUser = guild.members.cache.get(userIdentifier);
            if (!targetUser) {
                // ユーザー名で検索 (部分一致、大文字小文字を区別しない)
                targetUser = guild.members.cache.find(member => 
                    member.user.username.toLowerCase().includes(userIdentifier.toLowerCase())
                );
            }
            if (!targetUser) {
                return res.status(404).json({ error: `ユーザー「${userIdentifier}」が見つかりませんでした。` });
            }
        }

        const messages = await channel.messages.fetch({ limit: count });
        let filteredMessages = messages;
        if (targetUser) {
            filteredMessages = messages.filter(m => m.author.id === targetUser.id);
        }

        const deletedMessages = await channel.bulkDelete(filteredMessages, true);
        
        console.log(`[Web] ${req.user.username} deleted ${deletedMessages.size} messages from #${channel.name} in ${guild.name}`);
        res.json({ success: true, message: `${deletedMessages.size}件のメッセージを削除しました。` });

    } catch (error) {
        console.error('[Web] Error deleting messages:', error);
        res.status(500).json({ error: 'メッセージの削除に失敗しました。' });
    }
});

// API Endpoint to search for users in a guild
app.get('/api/guilds/:guildId/users', ensureApiAuth, (req, res) => {
    try {
        const { guildId } = req.params;
        const query = req.query.q ? req.query.q.toLowerCase() : '';

        const guild = client.guilds.cache.get(guildId);
        if (!guild) {
            return res.status(404).json({ error: 'Guild not found.' });
        }

        // メンバーキャッシュが最新であることを保証
        guild.members.fetch().then(fetchedMembers => {
            const users = fetchedMembers.filter(member => 
                member.user.username.toLowerCase().includes(query) || 
                member.user.id.includes(query)
            ).map(member => ({
                id: member.user.id,
                username: member.user.username,
                discriminator: member.user.discriminator, // 廃止予定だが互換性のため
                tag: member.user.tag, // username + discriminator
                avatarURL: member.user.displayAvatarURL(),
            }));
            res.json(users);
        }).catch(error => {
            console.error('[Web] Error fetching guild members:', error);
            res.status(500).json({ error: 'メンバーの取得に失敗しました。' });
        });

    } catch (error) {
        console.error('[Web] Error searching users:', error);
        res.status(500).json({ error: 'ユーザー検索に失敗しました。' });
    }
});

// API Endpoint to create a backup for a specific guild
app.post('/api/guilds/:guildId/backups', ensureApiAuth, async (req, res) => {
    try {
        const { guildId } = req.params;
        const { backupName, backupMessages } = req.body; // backupMessages を追加
        const userId = req.user.id;

        if (!backupName) {
            return res.status(400).json({ error: 'Backup name is required.' });
        }

        const guild = client.guilds.cache.get(guildId);
        if (!guild) {
            return res.status(404).json({ error: 'Guild not found.' });
        }

        await executeBackup({
            guild: guild,
            userId: userId,
            backupName: backupName,
            isAuto: false,
            backupMessages: !!backupMessages // booleanに変換
        });

        res.status(201).json({ success: true, message: `バックアップ「${backupName}」の作成を開始しました。` });

    } catch (error) {
        console.error('[Web] Error creating backup:', error);
        res.status(500).json({ error: 'バックアップの作成に失敗しました。' });
    }
});

// API Endpoint to restore a backup for a specific guild
app.post('/api/guilds/:guildId/restore', ensureApiAuth, async (req, res) => {
    try {
        const { guildId } = req.params;
        const { fileName } = req.body;
        const userId = req.user.id;

        if (!fileName) {
            return res.status(400).json({ error: 'File name is required.' });
        }

        const guild = client.guilds.cache.get(guildId);
        if (!guild) {
            return res.status(404).json({ error: 'Guild not found.' });
        }

        // Mock interaction object for executeRestore
        const mockInteraction = {
            guild: guild,
            user: { id: userId },
            options: {
                getString: (key) => {
                    if (key === 'file_name') return fileName;
                    return null;
                }
            },
            reply: async (options) => { console.log(`[Web-Restore] Reply: ${options.content}`); },
            followUp: async (options) => { console.log(`[Web-Restore] FollowUp: ${options.content}`); },
            deferReply: async () => { console.log('[Web-Restore] Reply deferred.'); }
        };

        await executeRestore(mockInteraction);

        res.json({ success: true, message: `バックアップ「${fileName}」からの復元を開始しました。` });

    } catch (error) {
        console.error('[Web] Error restoring backup:', error);
        res.status(500).json({ error: `復元に失敗しました: ${error.message}` });
    }
});

// --- Backup Schedule API Endpoints ---

app.get('/api/guilds/:guildId/schedules', ensureApiAuth, (req, res) => {
    const { guildId } = req.params;
    const schedulesForGuild = backupSchedules.get(guildId) || [];
    // taskオブジェクトを除外し、JSONに変換可能な形式で返す
    const serializableSchedules = schedulesForGuild.map(schedule => ({
        cronTime: schedule.cronTime,
        createdAt: schedule.createdAt,
        // 次回実行日時を計算して追加
        nextRun: CronExpressionParser.parse(schedule.cronTime, { tz: "Asia/Tokyo" }).next().toDate().toISOString(),
    }));
    res.json(serializableSchedules);
});

app.post('/api/guilds/:guildId/schedules', ensureApiAuth, async (req, res) => {
    try {
        const { guildId } = req.params;
        const { cronTime } = req.body;
        const userId = req.user.id; // The user who set up the schedule

        if (!cron.validate(cronTime)) {
            return res.status(400).json({ error: 'Invalid cron format.' });
        }

        await addSchedule(client, guildId, cronTime, userId);
        res.status(201).json({ success: true, message: `スケジュール「${cronTime}」を追加しました。` });

    } catch (error) {
        console.error('[Web] Error adding schedule:', error);
        res.status(500).json({ error: `スケジュールの追加に失敗しました: ${error.message}` });
    }
});

app.delete('/api/guilds/:guildId/schedules', ensureApiAuth, async (req, res) => {
    try {
        const { guildId } = req.params;
        const { cronTime } = req.body;

        await removeSchedule(guildId, cronTime);
        res.json({ success: true, message: `スケジュール「${cronTime}」を削除しました。` });

    } catch (error) {
        console.error('[Web] Error deleting schedule:', error);
        res.status(500).json({ error: `スケジュールの削除に失敗しました: ${error.message}` });
    }
});


app.get('/', (req, res) => {
    if (req.isAuthenticated()) {
        res.sendFile(path.join(__dirname, 'dashboard.html'));
    } else {
        res.sendFile(path.join(__dirname, 'login.html'));
    }
});

app.post('/api/log-error', (req, res) => {
    console.error('[Frontend Error]', req.body);
    res.status(204).send();
});

client.login(process.env.DISCORD_TOKEN);